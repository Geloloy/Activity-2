<?php
session_start();
include('db.php');
include('login_attempts.php');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<nav>
    <a href="login.php">Login</a>
    <a href="register.php">Register</a>
</nav>

<?php
$error = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];

    if (check_lockout($conn, $username)) {
        $error = "Too many failed attempts. Please try again after 2 minutes.";
    } else {
        $stmt = $conn->prepare("SELECT password FROM users WHERE username=?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->bind_result($hashed_password);
        if ($stmt->fetch()) {
            if (password_verify($_POST['password'], $hashed_password)) {
                record_attempt($conn, $username, true);
                $_SESSION['username'] = $username;
                header("Location: index.php");
                exit();
            } else {
                record_attempt($conn, $username, false);
                $error = "Incorrect password.";
            }
        } else {
            $error = "User not found.";
        }
        $stmt->close();
    }
}
?>

<form method="POST">
    <h2>Login</h2>
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <input type="submit" value="Login">
    <?php if ($error) echo "<p class='error'>$error</p>"; ?>
</form>
</body>
</html>
