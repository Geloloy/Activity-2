<?php
function check_lockout($conn, $username) {
    $stmt = $conn->prepare("SELECT attempts, last_attempt FROM login_attempts WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($attempts, $last_attempt);
    $exists = $stmt->fetch();
    $stmt->close(); // ✅ Always close before a new query

    if ($exists) {
        $lockout_time = strtotime($last_attempt) + 120; // 2 minutes
        if ($attempts >= 3 && time() < $lockout_time) {
            return true;
        }
    }
    return false;
}

function record_attempt($conn, $username, $success) {
    if ($success) {
        $stmt = $conn->prepare("DELETE FROM login_attempts WHERE username=?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->close();
    } else {
        $stmt = $conn->prepare("SELECT attempts FROM login_attempts WHERE username=?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->bind_result($attempts);
        $userExists = $stmt->fetch();
        $stmt->close(); // ✅ Close before the next query

        if ($userExists) {
            $stmt = $conn->prepare("UPDATE login_attempts SET attempts=attempts+1, last_attempt=NOW() WHERE username=?");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $stmt->close();
        } else {
            $stmt = $conn->prepare("INSERT INTO login_attempts (username, attempts, last_attempt) VALUES (?, 1, NOW())");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $stmt->close();
        }
    }
}
?>
